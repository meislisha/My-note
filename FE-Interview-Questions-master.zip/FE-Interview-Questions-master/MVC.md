**说说你对MVC和MVVM的理解**

- MVC
  - View 传送指令到 Controller

  - Controller 完成业务逻辑后，要求 Model 改变状态

  - Model 将新的数据发送到 View，用户得到反馈
  
所有通信都是单向的