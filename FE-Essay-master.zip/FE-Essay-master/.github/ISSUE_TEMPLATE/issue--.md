---
name: Issue模版
about: 如何正确提交一个issue
title: 文章编写出错
labels: bug
assignees: zhongsink, chaoming56, tubulang, LaamGinghong

---

> 请使用 Markdown 语法，方便大家查看。

## 文章编写错误

文章编写错误的位置，请用 文件名 + github 上面的行数来表述。

## 应该正确的结果

告诉我怎样才是正确的
