# 头条

## 一面

1.  position 有哪些属性

2.  `position: sticky` 用过吗

3.  typeof 原理，与 instanceof、`Object.prototype.toString.call` 的区别

    ![img](https://user-gold-cdn.xitu.io/2020/3/18/170e940c691b9396?imageslim)

4.  React的生命周期

5.  React 那些生命周期可以 setState

6.  提供一个vdom对象，写一个render函数让它变成一个DOM

7.  算法题：快排

## 二面

1.  为什么 0.1 + 0.2  !== 0.3
2.  算法题：字符串相加
3.  问我最近对什么技术感兴趣
4.  img 标签间距问题以及如何解决
5.  深拷贝

## 三面

1.  DNS 查询过程
2.  如果你发现一个网站打不开了，有哪些可能
3.  算法题：有一个“123456789101112131415 .... n+1" 这样的序列，求第 m 个数字
4.  有一个有序递增的序列，求有多少个不同的数字
5.  吹逼

## 四面

1.  红黑树和哈希表的对比
2.  哈希表如何解决冲突
3.  线程和进程的区别
4.  场景：有一个应用会经常创建、删除节点对象，如何优化（节电池）



# 虾皮

## 一面

1.  react this 绑定
2.  bind 和箭头函数的区别
3.  react 生命周期
4.  setState 同步异步
5.  vdom 渲染原理
6.  实现一个方法，将对象的键由下划线修改为小驼峰

## 二面

1.  es6模块管理和cjs 对比
2.  es6 装饰器
3.  es6+ 新特性
4.  吹逼
5.  base64原理，编码后体积大了还是小了
6.  非递归实现后序遍历



# 微信

## 一面

1.  [leetcode-cn.com/problems/in…](https://leetcode-cn.com/problems/intersection-of-two-arrays-ii/)

2.  [leetcode-cn.com/problems/va…](https://leetcode-cn.com/problems/valid-triangle-number/)

3.  这道题最难。。我使用了回溯法来做，不过不是正确答案，虽然刚好把测试用例都过了。[leetcode-cn.com/problems/sp…](https://leetcode-cn.com/problems/split-array-into-consecutive-subsequences/)

4.  setTimeout 的原理
5.  聊项目

## 二面

1.  吹逼
2.  react 和 vue 的区别
3.  spa 渲染的优缺点
4.  对前端框架的看法

## 三面

1.  微信小程序底层实现
2.  吹逼
3.  最近比较关心的技术

