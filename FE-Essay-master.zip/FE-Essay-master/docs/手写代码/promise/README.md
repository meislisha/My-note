# 手写 Promise A+

[TypeScript 版本 Promise A+](https://github.com/LaamGinghong/Promise-A-Plus)

